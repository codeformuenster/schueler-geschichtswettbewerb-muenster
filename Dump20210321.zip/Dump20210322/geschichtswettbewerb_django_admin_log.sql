-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: geschichtswettbewerb
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2021-03-21 14:26:24.297015','79','Diakonissenhaus id: 79',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(2,'2021-03-21 14:26:54.311751','171','Japan id: 171',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(3,'2021-03-21 14:28:44.430088','217','Lette id: 217',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(4,'2021-03-22 11:10:55.513431','400','Zwinger id: 400',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(5,'2021-03-22 11:11:44.658842','151','Hel id: 151',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(6,'2021-03-22 11:13:53.090695','330','Sibirien id: 330',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(7,'2021-03-22 11:15:33.073681','279','Pommern id: 279',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(8,'2021-03-22 11:16:54.071351','287','Rathaus id: 287',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(9,'2021-03-22 11:18:09.217181','107','Frauenstraße 24 id: 107',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(10,'2021-03-22 11:18:51.245749','363','Tschechoslowakei id: 363',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(11,'2021-03-22 11:19:29.264472','210','Lamberti-Kirche, Münster id: 210',2,'[]',22,1),(12,'2021-03-22 11:20:30.065235','209','Lamberti-Brunnen id: 209',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(13,'2021-03-22 11:21:46.305816','294','Rheinhausen id: 294',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(14,'2021-03-22 11:25:45.436804','125','Schloss Grafeneck id: 125',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(15,'2021-03-22 11:34:36.208629','295','Rieselfelder id: 295',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(16,'2021-03-22 11:37:03.879960','388','Westfälische Klinik id: 388',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(17,'2021-03-22 11:37:54.247951','245','Münsterland id: 245',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(18,'2021-03-22 11:39:51.591584','353','Sudetenland id: 353',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(19,'2021-03-22 11:40:17.570250','354','Synagoge, Münster id: 354',2,'[]',22,1),(20,'2021-03-22 14:17:34.892999','334','Sowjetunion id: 334',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1),(21,'2021-03-22 14:18:53.594331','281','Preußen id: 281',2,'[{\"changed\": {\"fields\": [\"Location\"]}}]',22,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-22 15:29:40
