-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: geschichtswettbewerb
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `karte_ort_histRegion`
--

DROP TABLE IF EXISTS `karte_ort_histRegion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `karte_ort_histRegion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ort_id` int NOT NULL,
  `historischeregion_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `karte_ort_histRegion_ort_id_historischeregion_id_e4ba27a5_uniq` (`ort_id`,`historischeregion_id`),
  KEY `karte_ort_histRegion_historischeregion_id_f8da13a8_fk_karte_his` (`historischeregion_id`),
  CONSTRAINT `karte_ort_histRegion_historischeregion_id_f8da13a8_fk_karte_his` FOREIGN KEY (`historischeregion_id`) REFERENCES `karte_historischeregion` (`id`),
  CONSTRAINT `karte_ort_histRegion_ort_id_c4f086ea_fk_karte_ort_id` FOREIGN KEY (`ort_id`) REFERENCES `karte_ort` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karte_ort_histRegion`
--

LOCK TABLES `karte_ort_histRegion` WRITE;
/*!40000 ALTER TABLE `karte_ort_histRegion` DISABLE KEYS */;
INSERT INTO `karte_ort_histRegion` VALUES (1,36,2),(2,55,3),(3,58,4),(4,76,5),(5,81,6),(6,90,7),(7,94,8),(10,114,11),(8,123,9),(9,126,10),(11,127,12),(12,151,13),(13,152,14),(14,205,15),(16,211,17),(17,250,18),(18,256,19),(19,278,20),(20,288,21),(21,333,22),(22,346,23),(15,378,16);
/*!40000 ALTER TABLE `karte_ort_histRegion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-22 15:29:45
