-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: geschichtswettbewerb
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add auszeichnung',7,'add_auszeichnung'),(26,'Can change auszeichnung',7,'change_auszeichnung'),(27,'Can delete auszeichnung',7,'delete_auszeichnung'),(28,'Can view auszeichnung',7,'view_auszeichnung'),(29,'Can add autorin',8,'add_autorin'),(30,'Can change autorin',8,'change_autorin'),(31,'Can delete autorin',8,'delete_autorin'),(32,'Can view autorin',8,'view_autorin'),(33,'Can add beitrag',9,'add_beitrag'),(34,'Can change beitrag',9,'change_beitrag'),(35,'Can delete beitrag',9,'delete_beitrag'),(36,'Can view beitrag',9,'view_beitrag'),(37,'Can add beitragsart',10,'add_beitragsart'),(38,'Can change beitragsart',10,'change_beitragsart'),(39,'Can delete beitragsart',10,'delete_beitragsart'),(40,'Can view beitragsart',10,'view_beitragsart'),(41,'Can add dokument typ',11,'add_dokumenttyp'),(42,'Can change dokument typ',11,'change_dokumenttyp'),(43,'Can delete dokument typ',11,'delete_dokumenttyp'),(44,'Can view dokument typ',11,'view_dokumenttyp'),(45,'Can add historische region',12,'add_historischeregion'),(46,'Can change historische region',12,'change_historischeregion'),(47,'Can delete historische region',12,'delete_historischeregion'),(48,'Can view historische region',12,'view_historischeregion'),(49,'Can add historischer ort',13,'add_historischerort'),(50,'Can change historischer ort',13,'change_historischerort'),(51,'Can delete historischer ort',13,'delete_historischerort'),(52,'Can view historischer ort',13,'view_historischerort'),(53,'Can add institution',14,'add_institution'),(54,'Can change institution',14,'change_institution'),(55,'Can delete institution',14,'delete_institution'),(56,'Can view institution',14,'view_institution'),(57,'Can add materialgrundlage',15,'add_materialgrundlage'),(58,'Can change materialgrundlage',15,'change_materialgrundlage'),(59,'Can delete materialgrundlage',15,'delete_materialgrundlage'),(60,'Can view materialgrundlage',15,'view_materialgrundlage'),(61,'Can add persoenlichkeit',16,'add_persoenlichkeit'),(62,'Can change persoenlichkeit',16,'change_persoenlichkeit'),(63,'Can delete persoenlichkeit',16,'delete_persoenlichkeit'),(64,'Can view persoenlichkeit',16,'view_persoenlichkeit'),(65,'Can add schulart',17,'add_schulart'),(66,'Can change schulart',17,'change_schulart'),(67,'Can delete schulart',17,'delete_schulart'),(68,'Can view schulart',17,'view_schulart'),(69,'Can add schule',18,'add_schule'),(70,'Can change schule',18,'change_schule'),(71,'Can delete schule',18,'delete_schule'),(72,'Can view schule',18,'view_schule'),(73,'Can add tutor',19,'add_tutor'),(74,'Can change tutor',19,'change_tutor'),(75,'Can delete tutor',19,'delete_tutor'),(76,'Can view tutor',19,'view_tutor'),(77,'Can add wettbewerb',20,'add_wettbewerb'),(78,'Can change wettbewerb',20,'change_wettbewerb'),(79,'Can delete wettbewerb',20,'delete_wettbewerb'),(80,'Can view wettbewerb',20,'view_wettbewerb'),(81,'Can add schule schulart',21,'add_schuleschulart'),(82,'Can change schule schulart',21,'change_schuleschulart'),(83,'Can delete schule schulart',21,'delete_schuleschulart'),(84,'Can view schule schulart',21,'view_schuleschulart'),(85,'Can add ort',22,'add_ort'),(86,'Can change ort',22,'change_ort'),(87,'Can delete ort',22,'delete_ort'),(88,'Can view ort',22,'view_ort'),(89,'Can add dokument',23,'add_dokument'),(90,'Can change dokument',23,'change_dokument'),(91,'Can delete dokument',23,'delete_dokument'),(92,'Can view dokument',23,'view_dokument'),(93,'Can add beitrag wettbewerb',24,'add_beitragwettbewerb'),(94,'Can change beitrag wettbewerb',24,'change_beitragwettbewerb'),(95,'Can delete beitrag wettbewerb',24,'delete_beitragwettbewerb'),(96,'Can view beitrag wettbewerb',24,'view_beitragwettbewerb'),(97,'Can add autorin schule',25,'add_autorinschule'),(98,'Can change autorin schule',25,'change_autorinschule'),(99,'Can delete autorin schule',25,'delete_autorinschule'),(100,'Can view autorin schule',25,'view_autorinschule'),(101,'Can add auszeichnung einreichung',26,'add_auszeichnungeinreichung'),(102,'Can change auszeichnung einreichung',26,'change_auszeichnungeinreichung'),(103,'Can delete auszeichnung einreichung',26,'delete_auszeichnungeinreichung'),(104,'Can view auszeichnung einreichung',26,'view_auszeichnungeinreichung');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-22 15:29:39
