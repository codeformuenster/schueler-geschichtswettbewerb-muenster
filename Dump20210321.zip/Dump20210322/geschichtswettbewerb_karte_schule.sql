-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: geschichtswettbewerb
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `karte_schule`
--

DROP TABLE IF EXISTS `karte_schule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `karte_schule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karte_schule`
--

LOCK TABLES `karte_schule` WRITE;
/*!40000 ALTER TABLE `karte_schule` DISABLE KEYS */;
INSERT INTO `karte_schule` VALUES (1,'Annette-von-Droste-Hülshoff-Gymnasium'),(2,'Astrid Lindgren-Schule'),(3,'Bodelschwinghschule'),(4,'Clemensschule'),(5,'Eichendorffgrundschule'),(6,'Erich-Klausener-Realschule'),(7,'Ernst-Immel-Realschule, Marl'),(8,'Freiherr-vom-Stein-Gymnasium'),(9,'Friedensschule'),(10,'Fürstin-von-Gallitzin Realschule'),(11,'Geistschule'),(12,'Gesamtschule Münster-Mitte'),(13,'Geschwister-Scholl-Gymnasium'),(14,'Geschwister-Scholl-Realschule'),(15,'Gymnasium Augustinianum Greven'),(16,'Gymnasium Martinum Emsdetten'),(17,'Gymnasium Paulinum'),(18,'Gymnasium St. Christophorus Werne'),(19,'Gymnasium St. Mauritz'),(20,'Gymnasium Wolbeck'),(21,'Hans-Böckler-Berufskolleg'),(22,'Hauptschule Münster-Nord'),(23,'Immanuel-Kant-Gymnasium'),(24,'Johann-Conrad-Schlaun-Gymnasium'),(25,'Johannes-Gutenberg-Realschule Hiltrup'),(26,'Johannisschule'),(27,'Kardinal-von-Galen Realschule Telgte'),(28,'Kardinal-von-Galen-Gymnasium'),(29,'Kardinal-von-Galen-Schule'),(30,'Keine Angabe'),(31,'Ludgerusschule'),(32,'Ludwig-Erhard-Berufskolleg '),(33,'Marienschule'),(34,'Martin-Luther-Schule'),(35,'Martinischule'),(36,'Mathilde Anneke Gesamtschule'),(37,'Montessori-Schule Münster'),(38,'Papst-Johannes-Schule'),(39,'Pascal-Gymnasium'),(40,'Paul-Gerhardt-Realschule'),(41,'Ratsgymnasium'),(42,'Realschule im Kreuzviertel'),(43,'Schillergymnasium'),(44,'Schule für Blinde und Sehbehinderte'),(45,'Sekundarschule an der Marienlinde'),(46,'Thomas-Morus-Schule'),(47,'Waldschule Kinderhaus'),(48,'Wartburg Grundschule'),(49,'Westfälische Wilhelms-Universität Münster'),(50,'Wilhelm-Hittorf-Gymnasium');
/*!40000 ALTER TABLE `karte_schule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-22 15:29:45
