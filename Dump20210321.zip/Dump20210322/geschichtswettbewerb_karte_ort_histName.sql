-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: geschichtswettbewerb
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `karte_ort_histName`
--

DROP TABLE IF EXISTS `karte_ort_histName`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `karte_ort_histName` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ort_id` int NOT NULL,
  `historischerort_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `karte_ort_histName_ort_id_historischerort_id_34664f93_uniq` (`ort_id`,`historischerort_id`),
  KEY `karte_ort_histName_historischerort_id_ea110146_fk_karte_his` (`historischerort_id`),
  CONSTRAINT `karte_ort_histName_historischerort_id_ea110146_fk_karte_his` FOREIGN KEY (`historischerort_id`) REFERENCES `karte_historischerort` (`id`),
  CONSTRAINT `karte_ort_histName_ort_id_405b9d32_fk_karte_ort_id` FOREIGN KEY (`ort_id`) REFERENCES `karte_ort` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karte_ort_histName`
--

LOCK TABLES `karte_ort_histName` WRITE;
/*!40000 ALTER TABLE `karte_ort_histName` DISABLE KEYS */;
INSERT INTO `karte_ort_histName` VALUES (2,34,2),(3,36,3),(4,55,4),(5,58,5),(6,76,6),(7,81,7),(8,90,8),(9,94,9),(12,114,12),(10,123,10),(11,126,11),(13,127,13),(14,151,14),(15,152,15),(16,205,16),(18,211,18),(19,250,19),(20,256,20),(21,278,21),(22,288,22),(23,333,23),(24,346,24),(17,378,17);
/*!40000 ALTER TABLE `karte_ort_histName` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-22 15:29:45
