-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: geschichtswettbewerb
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `karte_schuleschulart`
--

DROP TABLE IF EXISTS `karte_schuleschulart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `karte_schuleschulart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `art_id` int NOT NULL,
  `schule_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `karte_schuleschulart_schule_id_art_id_4b2df1eb_uniq` (`schule_id`,`art_id`),
  KEY `karte_schuleschulart_art_id_0c296d4c_fk_karte_schulart_id` (`art_id`),
  CONSTRAINT `karte_schuleschulart_art_id_0c296d4c_fk_karte_schulart_id` FOREIGN KEY (`art_id`) REFERENCES `karte_schulart` (`id`),
  CONSTRAINT `karte_schuleschulart_schule_id_35169953_fk_karte_schule_id` FOREIGN KEY (`schule_id`) REFERENCES `karte_schule` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karte_schuleschulart`
--

LOCK TABLES `karte_schuleschulart` WRITE;
/*!40000 ALTER TABLE `karte_schuleschulart` DISABLE KEYS */;
INSERT INTO `karte_schuleschulart` VALUES (1,5,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,3,6),(7,3,7),(8,5,8),(9,4,9),(10,5,9),(11,3,10),(12,2,11),(13,4,12),(14,5,12),(15,5,13),(16,5,14),(17,5,15),(18,5,16),(19,5,17),(20,5,18),(21,5,19),(22,5,20),(23,9,21),(24,2,22),(25,5,23),(26,5,24),(27,3,25),(28,1,26),(31,3,27),(29,5,28),(30,1,29),(32,1,31),(33,7,32),(34,5,33),(35,1,34),(36,1,35),(37,4,36),(38,1,37),(39,6,38),(40,5,39),(41,2,40),(42,3,40),(43,5,41),(44,5,42),(45,5,43),(46,6,44),(47,3,45),(48,1,46),(49,2,47),(50,1,48),(51,9,49),(52,5,50);
/*!40000 ALTER TABLE `karte_schuleschulart` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-21 20:00:36
