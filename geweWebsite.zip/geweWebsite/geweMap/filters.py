from .models import Ort
import django_filters

class OrtFilter(django_filters.FilterSet):
    class Meta:
        model = Ort
        fields = {
            'ortbezeichnung': ['icontains'],
        }
