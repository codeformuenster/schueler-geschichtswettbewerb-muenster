from django.shortcuts import render
from django.views.generic.base import TemplateView
from django.views import generic
from django.core.serializers import serialize
from .models import Ort, Beitrag

from .filters import OrtFilter

import json

#Create the start view
def index(request):
    num_places = Ort.objects.all().count()
    num_submissions = Beitrag.objects.all().count()
    context = {
        'num_places' : num_places,
        'num_submissions' : num_submissions,
    }
    return render(request, 'index.html', context = context)

class PlaceMapView(TemplateView):
    #View to display all places as markers on a map.
    model  = Ort
    template_name = 'map.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['markers'] = json.loads(serialize('geojson', Ort.objects.all()))
        return context

class PlaceListView(generic.ListView):
    model = Ort
    template_name = 'place_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter'] = OrtFilter(self.request.GET, queryset=self.get_queryset())
        return context

class PlaceDetailView(generic.DetailView):
    model = Ort
    template_name = 'place_detail.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['markers'] = json.loads(serialize('geojson', Ort.objects.all()))
        return context

#        <a href="{{ ort.get_absolute_url }}"></a>  {{ ort.ortbezeichnung }} ({{ort.id}})
