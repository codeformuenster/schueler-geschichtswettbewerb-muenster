from django.db import models
from django.contrib.gis.geos import Point
from django.contrib.gis.db.models import PointField

#Model for an award.
class Auszeichnung(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)
#Model for a school type
class Schulart(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)

#Model for a school
class Schule(models.Model):
    name = models.CharField(max_length=1024)
    art = models.ManyToManyField(Schulart, through = 'SchuleSchulart', blank=True)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)

class SchuleSchulart(models.Model):
    schule = models.ForeignKey(Schule, on_delete=models.CASCADE)
    art = models.ForeignKey(Schulart, on_delete=models.CASCADE)
    class Meta:
        unique_together = (('schule', 'art'),)


#Model for a competition
class Wettbewerb(models.Model):
    topic = models.TextField()
    shortTitle = models.TextField()
    year = models.IntegerField()
    summary = models.TextField(default = 'Zusammenfassung')

    def __str__(self):
        return self.topic + ' id: ' + str(self.id)

#Model for source material
class Materialgrundlage(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)

#Model for a document type
class DokumentTyp(models.Model):
    typName = models.CharField(max_length=255)

    def __str__(self):
        return self.typName + ' id: ' + str(self.id)

#Model for a document
class Dokument(models.Model):
    doc = models.FileField()
    typ = models.ForeignKey(DokumentTyp, on_delete=models.CASCADE)

#Model for an institution
class Institution(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)
#Model for a tutor
class Tutor(models.Model):
    code = models.CharField(max_length=255)
    firstName = models.CharField(max_length=255, null=True)
    surname = models.CharField(max_length=255, null=True)

    def __str__(self):
        return self.code + ' id: ' + str(self.id)

#Model for a personality
class Persoenlichkeit(models.Model):
    name = models.CharField(max_length=255)
    gnd = models.CharField(max_length=255, null=True)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)

class Beitragsart(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)

#Model for a submission.
class Beitrag(models.Model):
    title = models.CharField(max_length=1024)
    regest = models.TextField()
    sinatur = models.CharField(max_length=255)
    einzel_gruppe = models.BooleanField(default=True)
    umfang = models.IntegerField()
    zeitraumVon = models.IntegerField()
    zeitraumBis = models.IntegerField()
    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE, null=True)
    dokument = models.ManyToManyField(Dokument, blank=True)
    grundlagen = models.ManyToManyField(Materialgrundlage, blank=True)
    persoenlichkeiten = models.ManyToManyField(Persoenlichkeit, blank=True)
    institutionen = models.ManyToManyField(Institution, blank=True)
    typ = models.ManyToManyField(Beitragsart, blank=True)
    wettbewerb = models.ManyToManyField(Wettbewerb, through='BeitragWettbewerb', blank=True)

    def __str__(self):
        return self.title + ' id: ' + str(self.id)

#Model for wettbewerb-beitrag
class BeitragWettbewerb(models.Model):
    beitrag = models.ForeignKey(Beitrag, on_delete=models.CASCADE, null=True, unique=True)
    wettbewerb = models.ForeignKey(Wettbewerb, on_delete=models.CASCADE)
    class Meta:
        unique_together = (('beitrag', 'wettbewerb'),)

#Model for an author.
class Autorin(models.Model):
    firstName = models.CharField(max_length=255, null=True)
    surname = models.CharField(max_length=255, null=True)
    schule = models.ManyToManyField(SchuleSchulart, through='AutorinSchule', blank=True)
    beitrag = models.ForeignKey(Beitrag, on_delete=models.CASCADE)

    def __str__(self):
        return self.firstName + ' ' + self.surname

class AutorinSchule(models.Model):
    autorin = models.ForeignKey(Autorin, on_delete=models.CASCADE)
    schule = models.ForeignKey(SchuleSchulart, on_delete=models.CASCADE)
    grade = models.IntegerField(null=True)
    class Meta:
        unique_together = (('schule', 'autorin'),)

#Model for Award and handed submissions
class AuszeichnungEinreichung(models.Model):
    einreichung = models.ForeignKey(Beitrag, on_delete=models.CASCADE, null=True)
    auszeichnung = models.ForeignKey(Auszeichnung, on_delete=models.CASCADE, null=True)

#Model for a historical place
class HistoricPlace(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)
#Model for a historical region
class HistoricRegion(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name + ' id: ' + str(self.id)
#Model for a place
class Ort(models.Model):
    ortbezeichnung = models.CharField(max_length=255)
    location = PointField(geography=True, default=Point(0.0, 0.0))
    beitraege = models.ManyToManyField(Beitrag, blank=True)
    histName = models.ManyToManyField(HistoricPlace, blank=True)
    histRegion = models.ManyToManyField(HistoricRegion, blank=True)

    def __str__(self):
        return self.ortbezeichnung + ' id: ' + str(self.id)
