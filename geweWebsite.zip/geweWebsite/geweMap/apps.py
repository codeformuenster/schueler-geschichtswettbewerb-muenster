from django.apps import AppConfig


class GewemapConfig(AppConfig):
    name = 'geweMap'
