from django.urls import path
from .views import PlaceMapView, PlaceListView
from geweMap import views
from django.views.generic import RedirectView

app_name = 'geweMap'

urlpatterns = [
    path('', views.index, name='index'),
    path('map/', PlaceMapView.as_view(), name = 'map'),
    path('places/', views.PlaceListView.as_view(), name='places'),
    path('map/<int:pk>', views.PlaceDetailView.as_view(), name='ort-detail'),
    path('places/<int:pk>', views.PlaceDetailView.as_view(), name='ort-detail'),
]
#  {{ markers|json_script:"markers-data" }}
