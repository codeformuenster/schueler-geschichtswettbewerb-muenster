from .models import Ort
import django_filters

class OrtFilter(django_filters.FilterSet):
    """Class to filter place data"""
    class Meta:
        """Class to apply the filter on the ortbezeichnung attribute of the Ort model"""
        model = Ort
        fields = {
            'ortbezeichnung': ['icontains'],
        }
