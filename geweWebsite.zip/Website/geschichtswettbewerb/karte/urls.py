from django.urls import path
from .views import PlaceMapView, PlaceListView
from karte import views
from django.views.generic import RedirectView

app_name = 'karte'

urlpatterns = [
    path('', views.index, name='index'),
    path('karte/', PlaceMapView.as_view(), name = 'karte'),
    path('orte/', views.PlaceListView.as_view(), name='orte'),
    path('karte/<int:pk>', views.PlaceDetailView.as_view(), name='ort-detail'),
    path('orte/<int:pk>', views.PlaceDetailView.as_view(), name='ort-detail'),
]
