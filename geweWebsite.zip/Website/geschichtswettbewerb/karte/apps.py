from django.apps import AppConfig


class KarteConfig(AppConfig):
    name = 'karte'
